class AppAsset {
  static const slider1 = "assets/icon/slider1.webp";
  static const slider2 = "assets/icon/slider2.webp";
  static const slider3 = "assets/icon/slider3.webp";
  static const slider4 = "assets/icon/slider4.webp";
  static const slider5 = "assets/icon/slider5.webp";
  static const slider6 = "assets/icon/slider6.webp";
  static const craftBox = "assets/icon/craftBox.webp";
  static const dazeOhmlet = "assets/icon/daze ohmlet.webp";
  static const FLUMPebble = "assets/icon/FLUM pebble.webp";
  static const geekVapeBoost = "assets/icon/geek vape boost.webp";
  static const greekBarPluse = "assets/icon/greek bar pluse.webp";
  static const horizonSakerzMaster = "assets/icon/horizon sakerz master.webp";
  static const lostMaryPuff = "assets/icon/lost mary puff.webp";
  static const lostMary = "assets/icon/lost mary.webp";
  static const luffbar = "assets/icon/luffbar.webp";
  static const shisha = "assets/icon/shisha.webp";
  static const spaceman = "assets/icon/spaceman.webp";
  static const puffBrandsHotbox = "assets/icon/puff brands hotbox.webp";
  static const TurboStrawberryOrange =
      "assets/icon/Turbo_Strawberry-Orange.webp";
  static const vapeGangMega = "assets/icon/vape gang mega.webp";
  static const vaporesso_xros = "assets/icon/vaporesso_xros.webp";
  static const vaporesso = "assets/icon/vaporesso.webp";
  static const vgodSaltPeachMango = "assets/icon/vgod salt peach mango.webp";
  static const vgodSaltWatermelon = "assets/icon/vgod salt watermelon.webp";
  static const vgodSalt = "assets/icon/vgod salt.webp";
  static const yogiBar = "assets/icon/yogi bar.webp";
}
