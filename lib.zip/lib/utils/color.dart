import 'package:flutter/material.dart';

Color red = const Color(0xFFF44336);
Color blue = const Color(0xFF4897D6);
Color grey = const Color(0xFFA5A8B2);
Color white = const Color(0xFFFFFFFF);
Color black = const Color(0xFF000000);
Color lightgrey = const Color(0xFFF1F1F3);
Color primaryColor = const Color(0xFF232F3F);
Color backgroundColor = const Color(0xFFF3F5F6);
Color orange = const Color(0xFFFF9900);
const kDefaultPadding = 20.0;
