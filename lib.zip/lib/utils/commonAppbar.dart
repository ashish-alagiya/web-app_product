import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:webappdemo/modules/home_screen/controller/homecontroller.dart';
import 'package:webappdemo/modules/home_screen/view/accessories.dart';
import 'package:webappdemo/modules/home_screen/view/disposables.dart';
import 'package:webappdemo/modules/home_screen/view/eliquid_view.dart';
import 'package:webappdemo/modules/home_screen/view/pod_systems.dart';
import 'package:webappdemo/modules/home_screen/view/starter_kids.dart';
import 'package:webappdemo/modules/home_screen/view/tanks_view.dart';
import 'package:webappdemo/modules/home_screen/view/vgod.dart';
import 'package:webappdemo/utils/color.dart';
import 'package:webappdemo/utils/responsive_widget.dart';

// ignore: non_constant_identifier_names
Widget CommonAppBar(BuildContext context) {
  final controller = Get.put(HomeController());

  return Column(
    children: [
      Container(
        height: Responsive.isDesktop(context)
            ? 130
            : Responsive.isTablet(context)
                ? 130
                : 100,
        width: double.infinity,
        decoration: BoxDecoration(color: primaryColor),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            children: [
              if (Responsive.isDesktop(context))
                Text(
                  "FREE SHIPPING ON ORDERS 100+",
                  style: TextStyle(color: orange),
                ),
              const SizedBox(
                height: 15,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    // if (!Responsive.isDesktop(context))
                    //   IconButton(
                    //     icon: Icon(
                    //       Icons.menu,
                    //       color: white,
                    //       size: 30,
                    //     ),
                    //     onPressed: () {
                    //       controller.scaffoldKey.currentState?.openDrawer();
                    //     },
                    //   ),
                    const SizedBox(
                      width: 15,
                    ),
                    Expanded(
                        flex: 5,
                        child: Container(
                          height: 50,
                          decoration: BoxDecoration(
                              color: white,
                              borderRadius: BorderRadius.circular(5)),
                          // ignore: prefer_const_constructors
                          child: Row(
                            children: [
                              const Flexible(
                                  flex: 12,
                                  child: TextField(
                                    decoration: InputDecoration(
                                        contentPadding: EdgeInsets.symmetric(
                                            horizontal: 25),
                                        border: InputBorder.none,
                                        hintText: "Search here..."),
                                  )),
                              Flexible(
                                  flex: Responsive.isDesktop(context) ? 1 : 2,
                                  child: Container(
                                    width: double.infinity,
                                    height: 50,
                                    color: blue,
                                    child: Icon(
                                      Icons.search,
                                      color: white,
                                      size: 30,
                                    ),
                                  ))
                            ],
                          ),
                        )),
                    const SizedBox(
                      width: 20,
                    ),
                    Expanded(
                        flex: Responsive.isDesktop(context)
                            ? 2
                            : Responsive.isTablet(context)
                                ? 3
                                : 3,
                        child: Responsive.isMobile(context)
                            ? Container(
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.person,
                                      color: white,
                                    ),
                                    Icon(
                                      Icons.shopping_cart_sharp,
                                      color: white,
                                    )
                                  ],
                                ),
                              )
                            : SizedBox(
                                height: 50,
                                child: Row(
                                  children: [
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Login / Signup",
                                          style: TextStyle(color: blue),
                                        ),
                                        Text(
                                          "My account ",
                                          style: TextStyle(
                                              color: white,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      width: 20,
                                    ),
                                    Container(
                                      height: 80,
                                      width: 1,
                                      color: blue,
                                    ),
                                    const SizedBox(
                                      width: 20,
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.shopping_cart_sharp,
                                          color: white,
                                        ),
                                        const SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          "Cart",
                                          style: TextStyle(
                                              color: white,
                                              fontWeight: FontWeight.bold),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ))
                  ],
                ),
              )
            ],
          ),
        ),
      ),
      if (Responsive.isDesktop(context))
        Material(
          elevation: 1,
          child: Container(
            height: 70,
            width: double.infinity,
            decoration: BoxDecoration(color: white),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Text(
                    "HOME",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return EliquidView();
                      },
                    ));
                  },
                  child: Text(
                    "ELIQUID",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return const DisposablesView();
                      },
                    ));
                  },
                  child: Text(
                    "DISPOSABLES",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return const PodSystemView();
                      },
                    ));
                  },
                  child: Text(
                    "POD SYSTEMS",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return StarterKidsView();
                      },
                    ));
                  },
                  child: Text(
                    "STARTER KITS",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return TanksView();
                      },
                    ));
                  },
                  child: Text(
                    "TANKS",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return AccessoriesView();
                      },
                    ));
                  },
                  child: Text(
                    "ACCESSORIES",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(
                      builder: (context) {
                        return VgodView();
                      },
                    ));
                  },
                  child: Text(
                    "VGOD",
                    style: TextStyle(color: black, fontSize: 18),
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
              ],
            ),
          ),
        ),
    ],
  );
}
