import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:webappdemo/modules/home_screen/view/accessories.dart';
import 'package:webappdemo/modules/home_screen/view/disposables.dart';
import 'package:webappdemo/modules/home_screen/view/eliquid_view.dart';
import 'package:webappdemo/modules/home_screen/view/pod_systems.dart';
import 'package:webappdemo/modules/home_screen/view/starter_kids.dart';
import 'package:webappdemo/modules/home_screen/view/tanks_view.dart';
import 'package:webappdemo/modules/home_screen/view/vgod.dart';
import 'package:webappdemo/utils/color.dart';
import 'package:webappdemo/utils/sidemenu_components/side_menu_item.dart';

Widget SideMenu(BuildContext context) {
  return Container(
    height: double.infinity,
    padding: const EdgeInsets.only(top: kIsWeb ? kDefaultPadding : 0),
    color: white,
    child: SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: kDefaultPadding),
        child: Column(
          children: [
            const SizedBox(height: kDefaultPadding),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
              },
              title: "HOME",
              itemCount: 3,
            ),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return EliquidView();
                  },
                ));
              },
              title: "ELIQUID",
            ),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return DisposablesView();
                  },
                ));
              },
              title: "DISPOSABLES",
            ),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return PodSystemView();
                  },
                ));
              },
              title: "POD SYSTEMS",
            ),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return StarterKidsView();
                  },
                ));
              },
              title: "STARTER KITS",
            ),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return TanksView();
                  },
                ));
              },
              title: "TANKS",
            ),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return AccessoriesView();
                  },
                ));
              },
              title: "ACCESSORIES",
            ),
            SideMenuItem(
              press: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(
                  builder: (context) {
                    return VgodView();
                  },
                ));
              },
              title: "VGOD",
            ),
            const SizedBox(height: kDefaultPadding * 2),
          ],
        ),
      ),
    ),
  );
}
