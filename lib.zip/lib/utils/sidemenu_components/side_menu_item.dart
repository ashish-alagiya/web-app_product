import 'package:flutter/material.dart';
import 'package:webappdemo/utils/color.dart';

class SideMenuItem extends StatelessWidget {
  const SideMenuItem({
    super.key,
    this.itemCount,
    required this.title,
    required this.press,
  });

  final int? itemCount;
  final String title;
  final VoidCallback press;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: kDefaultPadding),
      child: InkWell(
        onTap: press,
        child: Row(
          children: [
            const SizedBox(width: kDefaultPadding / 4),
            Expanded(
              child: Container(
                padding: const EdgeInsets.only(bottom: 15, right: 5),
                child: Row(
                  children: [
                    Container(
                      height: 10,
                      width: 10,
                      decoration:
                          BoxDecoration(color: black, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: kDefaultPadding * 0.75),
                    Text(
                      title,
                      style: Theme.of(context)
                          .textTheme
                          .labelLarge
                          ?.copyWith(color: black),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
