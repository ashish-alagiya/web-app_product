// ignore_for_file: constant_identifier_names

part of 'app_pages.dart';

abstract class Routes {
  Routes._();
  static const SIGN_UP = _Paths.SIGN_UP;
  static const HOME_SCREEN = _Paths.HOME_SCREEN;
  static const ADD_PRODUCT = _Paths.ADD_PRODUCT;
}

abstract class _Paths {
  _Paths._();
  static const SIGN_UP = '/sign-up';
  static const HOME_SCREEN = '/home-screen';
  static const ADD_PRODUCT = '/add-product';
}
